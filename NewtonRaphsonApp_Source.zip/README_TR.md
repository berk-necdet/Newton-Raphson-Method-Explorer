# Newton-Raphson Method Explorer

Bu teslim, 18 hazır Newton-Raphson senaryosunu ve cursor destekli özel fonksiyon hesap makinesini içeren İngilizce arayüzlü MATLAB uygulamasıdır.

## Dosyalar

- `NewtonRaphsonApp.m`: Çalışan tek dosyalı MATLAB uygulaması.
- `buildStandalone.m`: MATLAB Compiler ile Windows `.exe` ve kurulum paketi üretir.
- `README_TR.md`: Bu kullanım ve dağıtım notları.

## MATLAB içinde çalıştırma

MATLAB Current Folder'ı bu klasöre getirip şunu çalıştırın:

```matlab
NewtonRaphsonApp
```

İç testleri çalıştırmak için:

```matlab
NewtonRaphsonApp('SelfTest', true)
```

## Custom Function ve cursor kullanımı

1. Soldan **CUSTOM FUNCTION** seçin.
2. **OPEN FUNCTION CALCULATOR** düğmesine basın.
3. Üstteki açılır listeden `f(x)` veya `f'(x)` seçin. İki ifade kendi cursor konumunu ayrı tutar.
4. `<` ve `>` ile ifadenin içinde hareket edin. Ekrandaki `|` cursor konumudur.
5. **DEL**, cursor'ın solundaki tanınan fonksiyon token'ını (ör. `acos(`) veya tek karakteri siler.
6. **FWD DEL**, cursor'ın sağındaki token'ı veya karakteri siler.
7. Yeni tuşlar cursor'ın bulunduğu yere eklenir.
8. **APPLY AND CLOSE** sonrasında ana pencerede **RUN** düğmesine basın.

Örnek Interior Goat Problem fonksiyonu:

```text
x^2*acos(x/2)+acos(1-x^2/2)-x/2*sqrt(4-x^2)-pi/2
```

Analitik türevi:

```text
2*x*acos(x/2)
```

`x0 = 1.2` ile sonuç yaklaşık `1.158728473` olmalıdır.

## Davranışlar

- Senaryo seçmek sadece senaryoyu yükler; çözüm yalnızca **RUN** ile başlar.
- **STOP**, devam eden animasyonu güvenli biçimde durdurur.
- **Analytical** ve **Numerical** derivative seçenekleri korunmuştur.
- Animasyon gecikmesi, tolerans, maksimum iterasyon ve grafik sınırları değiştirilebilir.
- Canlı Newton hesabı, teğet çizimi, sonuçlar ve iterasyon tablosu birlikte güncellenir.

## MATLAB'sız Windows uygulaması üretme

Bu klasörde MATLAB Command Window'dan:

```matlab
buildStandalone
```

komutunu çalıştırın. MATLAB Compiler gerekir. Script:

- `standalone_build` içinde `NewtonRaphsonExplorer.exe` üretir;
- `installer` içinde `NewtonRaphsonExplorerInstaller` kurulum paketini üretir;
- küçük kurulum paketi için MATLAB Runtime'ı kurulum sırasında internetten indirir.

Hedef bilgisayarda lisanslı MATLAB gerekmez; derleme sürümüyle eşleşen MATLAB Runtime gerekir. Derlenen uygulama platforma özeldir; bu script Windows çıktısı üretir.

İsterseniz grafik arayüzü de kullanabilirsiniz: MATLAB'da `standaloneApplicationCompiler` komutunu çalıştırın, ana dosya olarak `NewtonRaphsonApp.m` seçin ve uygulama türünü **Standalone Windows Application** yapın.

## `.mlapp` ve MATLAB App paketi hakkında

Bu sürüm programatik `uifigure` kullanan, tek dosyalı ve standalone derlemeye uygun bir `.m` uygulamasıdır. R2025a ve sonrasında yeni MATLAB App paylaşım biçimi App Designer içinden `.mlapp` kaynakla oluşturulan `.mltbx` paketidir. Kaynak kodu otomatik ve güvenilir biçimde `.mlapp` ikili dosyasına dönüştüren desteklenen bir komut olmadığı için bu teslimde sahte/elle üretilmiş `.mlapp` verilmemiştir.

## Telefon ve web kullanımı

`uifigure` tabanlı desktop uygulama Android veya iPhone üzerinde doğrudan çalışmaz. Telefon erişimi için iki gerçekçi yol vardır:

1. App Designer'a port + MATLAB Web App Server: Uygulamayı `.mlapp` olarak yeniden kurun, MATLAB Compiler ile web app arşivi oluşturun ve MATLAB Web App Server'a dağıtın. Kullanıcı telefondan tarayıcıyla bağlanır. Web App Server güvenilen intranet ortamı için tasarlanmıştır.
2. Web tabanlı yeniden yazım: Newton motorunu JavaScript/TypeScript veya bir sunucu API'sine taşıyın; grafiği Plotly/D3, arayüzü responsive HTML/CSS ile kurun. Açık internet ve mobil kullanım için daha esnek yoldur.

Kısa Web App Server yol haritası:

1. Programatik arayüzü App Designer bileşenlerine taşı.
2. Cursor editörü, senaryo bankası ve Newton motorunu App Designer callback/metotlarına ayır.
3. Telefon ekranı için tek kolonlu responsive yerleşim ekle.
4. App Designer **Share > Web App** ile `.ctf` üret.
5. Yetkilendirilmiş MATLAB Web App Server'a yükle ve gerçek telefon tarayıcılarında test et.

## Uyum notu

Bu sürüm MATLAB R2026a üzerinde Code Analyzer, iç self-test ve görünmez `uifigure` açılış testiyle doğrulanmıştır.

### R2026a Runtime düzeltmesi

İlk kurulum paketinde R2026a Runtime web kurucusunun atladığı `libmwflproxycredentialapi.dll` nedeniyle uygulama başlangıcında “Belirtilen modül bulunamadı” hatası oluşabiliyordu. Düzeltilmiş paket bu DLL'i uygulamanın yanına kurar.

### Sürüm 1.1.0

Sağ üst bilgi paneli yenilendi. Newton-Raphson formülünün altında seçili senaryonun veya Custom Function modunun `f(x)` fonksiyonu turkuaz, `f'(x)` türevi sarı renkle sürekli gösterilir. Numerical derivative seçildiğinde türev satırı merkezi fark kullanıldığını belirtir.
